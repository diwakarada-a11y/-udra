RUDRA - setup
1. Android Studio -> Open -> is Rudra folder. Gradle sync hone do (internet chahiye).
2. Phone par USB debugging on karke Run, ya Build > Build APK(s).
3. App kholo, buttons 1 se 4 tak permissions do (Accessibility mein "Rudra" on karo).
   Agar "Restricted setting" aaye: Settings > Apps > Rudra > 3-dot > Allow restricted settings.
4. START Rudra dabao. Bolo: "Rudra, open Instagram", "Rudra, next reel", "Rudra, comment superb",
   "Rudra, Rahul ko WhatsApp karo ki main 5 baje aaunga", "Rudra, call Rahul", "Rudra, torch".
Unlock: Settings > Security > Smart Lock use karo (PIN bypass Android allow nahi karta).

APK bina PC ke: is folder ko GitHub repo mein upload karo -> Actions tab -> "Build Rudra APK" -> Run workflow -> artifact "Rudra-APK" download karo -> install.
