package com.rudra.assistant

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

/** Dynamic-Island style pill: small black capsule that expands with text, then shrinks and hides. */
class Pill(private val c: Context) {
    private val wm = c.getSystemService(WindowManager::class.java)
    private val h = Handler(Looper.getMainLooper())
    private var added = false
    private fun dp(v: Int) = (v * c.resources.displayMetrics.density).toInt()
    private val tv = TextView(c).apply {
        setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER; maxLines = 2
        setPadding(dp(16), dp(10), dp(16), dp(10))
        background = GradientDrawable().apply { setColor(Color.BLACK); cornerRadius = dp(40).toFloat() }
    }
    private val lp = WindowManager.LayoutParams(
        dp(110), WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(24) }

    private fun anim(to: Int, end: (() -> Unit)? = null) {
        ValueAnimator.ofInt(lp.width, to).apply {
            duration = 280
            addUpdateListener { lp.width = it.animatedValue as Int; if (added) wm.updateViewLayout(tv, lp) }
            addListener(object : android.animation.AnimatorListenerAdapter() { override fun onAnimationEnd(a: android.animation.Animator) { end?.invoke() } })
            start()
        }
    }

    fun show(text: String) = h.post {
        if (!Settings.canDrawOverlays(c)) return@post
        tv.text = text
        if (!added) { lp.width = dp(110); wm.addView(tv, lp); added = true }
        anim(dp(320))
        h.removeCallbacksAndMessages(null)
        h.postDelayed({ anim(dp(110)) { if (added) { wm.removeView(tv); added = false } } }, 3500)
    }

    fun destroy() { h.removeCallbacksAndMessages(null); if (added) { wm.removeView(tv); added = false } }
}
