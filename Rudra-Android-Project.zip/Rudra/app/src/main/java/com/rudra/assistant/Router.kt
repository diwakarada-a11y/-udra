package com.rudra.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.ContactsContract
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Router {
    private val h = Handler(Looper.getMainLooper())
    private var torch = false
    private fun has(s: String, vararg k: String) = k.any { s.contains(it) }
    private val alias = mapOf("इंस्टाग्राम" to "instagram", "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "यूट्यूब" to "youtube",
        "गूगल" to "google", "कैमरा" to "camera", "सेटिंग" to "settings", "क्रोम" to "chrome")

    fun handle(c: Context, raw: String, say: (String) -> Unit) {
        val s = raw.lowercase().trim()
        val a = RudraAccessibility.instance
        fun acc(f: (RudraAccessibility) -> Unit) { if (a == null) say("Pehle Accessibility on kijiye") else f(a) }

        // WhatsApp: "rahul ko whatsapp karo ki main 5 baje aaunga"  /  "whatsapp rahul main aa raha hoon"
        Regex("(.+?)\\s+(?:ko|को)\\s+(?:whatsapp|व्हाट्सएप|message|msg|मैसेज).*?(?:ki|कि|that)\\s+(.+)").find(s)?.let { m ->
            return whatsapp(c, m.groupValues[1], m.groupValues[2], say) }
        Regex("(?:whatsapp|व्हाट्सएप)\\s+(?:to\\s+)?(\\S+)\\s+(.+)").find(s)?.let { m ->
            return whatsapp(c, m.groupValues[1], m.groupValues[2], say) }

        // Instagram comment: "comment wow nice reel"
        Regex("(?:comment|कमेंट)\\s+(.+)").find(s)?.let { m ->
            acc { x ->
                say("Comment kar raha hoon")
                x.click("Comment", "कमेंट")
                h.postDelayed({ x.type(m.groupValues[1]) }, 1500)
                h.postDelayed({ x.click("Post", "पोस्ट") }, 2300)
            }; return
        }
        // Call
        Regex("(?:call|कॉल|फोन)\\s+(.+)").find(s)?.let { m ->
            val q = m.groupValues[1].replace(" ", "")
            val num = if (q.matches(Regex("[+\\d]{6,}"))) q else phoneOf(c, m.groupValues[1].replace("karo", "").trim())
            if (num == null) say("Contact nahi mila") else {
                say("Call laga raha hoon")
                c.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }; return
        }
        // Open app
        Regex("(?:open|launch|kholo|khol|खोलो|खोल)\\s+(.+?)(?:\\s+(?:karo|kholo|खोलो))?$").find(s)?.let { m ->
            return openApp(c, m.groupValues[1].trim(), say) }
        Regex("(.+?)\\s+(?:kholo|khol do|खोलो|खोल दो)$").find(s)?.let { m -> return openApp(c, m.groupValues[1].trim(), say) }

        when {
            has(s, "flashlight", "torch", "टॉर्च", "फ्लैशलाइट") -> {
                val cm = c.getSystemService(CameraManager::class.java); torch = !torch
                runCatching { cm.setTorchMode(cm.cameraIdList[0], torch) }; say(if (torch) "Torch on" else "Torch off")
            }
            has(s, "next reel", "agla reel", "अगली रील", "scroll down", "neeche", "नीचे", "next") -> acc { it.swipe(true) }
            has(s, "previous reel", "pichla reel", "scroll up", "upar", "ऊपर", "previous") -> acc { it.swipe(false) }
            has(s, "like", "लाइक") -> acc { if (!it.click("Like", "Unlike")) it.doubleTapCenter() }
            has(s, "follow", "फॉलो") -> acc { it.click("Follow", "फॉलो") }
            has(s, "send", "भेजो") -> acc { it.click("Send", "भेजें") }
            has(s, "back", "peeche", "पीछे", "वापस") -> acc { it.global(AccessibilityService.GLOBAL_ACTION_BACK) }
            has(s, "recent", "रीसेंट") -> acc { it.global(AccessibilityService.GLOBAL_ACTION_RECENTS) }
            s == "home" || has(s, "home screen", "होम") -> acc { it.global(AccessibilityService.GLOBAL_ACTION_HOME) }
            has(s, "screen on", "wake", "jaago", "जागो") -> {
                @Suppress("DEPRECATION")
                (c.getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(
                    PowerManager.FULL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "rudra:wake").acquire(5000)
                say("Screen on")
            }
            has(s, "time", "samay", "kitne baje", "समय", "बजे") -> say("Abhi " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + " hue hain")
            has(s, "who are you", "tum kaun", "तुम कौन") -> say("Main Rudra hoon, aapka assistant")
            has(s, "stop", "band karo", "बंद करो", "chup") -> say("Theek hai")
            else -> {
                say("Google par dhoond raha hoon")
                c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(raw))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }

    private fun openApp(c: Context, name0: String, say: (String) -> Unit) {
        val name = alias[name0] ?: name0
        val pm = c.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val hit = pm.queryIntentActivities(q, 0).firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
        val li = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (li == null) say("$name nahi mila") else { say("$name khol raha hoon"); c.startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    private fun phoneOf(c: Context, name: String): String? {
        val p = ContactsContract.CommonDataKinds.Phone
        c.contentResolver.query(p.CONTENT_URI, arrayOf(p.NUMBER), "${p.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)
            ?.use { if (it.moveToFirst()) return it.getString(0).replace(Regex("[^+\\d]"), "") }
        return null
    }

    private fun whatsapp(c: Context, who: String, msg: String, say: (String) -> Unit) {
        var n = if (who.replace(" ", "").matches(Regex("[+\\d]{10,}"))) who.replace(" ", "") else phoneOf(c, who.trim())
        if (n == null) { say("${who.trim()} contact nahi mila"); return }
        if (n.length == 10) n = "91$n"
        n = n.removePrefix("+")
        say("${who.trim()} ko message bhej raha hoon")
        c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$n?text=" + Uri.encode(msg)))
            .setPackage("com.whatsapp").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        h.postDelayed({ RudraAccessibility.instance?.click("Send", "भेजें") }, 3000)
    }
}
