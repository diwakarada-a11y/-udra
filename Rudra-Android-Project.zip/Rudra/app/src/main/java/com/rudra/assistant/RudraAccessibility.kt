package com.rudra.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class RudraAccessibility : AccessibilityService() {
    companion object { var instance: RudraAccessibility? = null }
    override fun onServiceConnected() { instance = this }
    override fun onUnbind(i: Intent?): Boolean { instance = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun global(a: Int) = performGlobalAction(a)

    /** Click first node whose text or content-description matches any label (case-insensitive). */
    fun click(vararg labels: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (l in labels) for (n in root.findAccessibilityNodeInfosByText(l)) {
            var x: AccessibilityNodeInfo? = n
            while (x != null && !x.isClickable) x = x.parent
            if (x != null && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    fun type(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isEditable) return n
        for (i in 0 until n.childCount) n.getChild(i)?.let { findEditable(it)?.let { r -> return r } }
        return null
    }

    private fun gesture(path: Path, ms: Long) {
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, ms)).build()
        dispatchGesture(g, null, null)
    }

    /** next = swipe up (next reel / scroll down). */
    fun swipe(next: Boolean) {
        val m = resources.displayMetrics; val x = m.widthPixels / 2f
        val a = m.heightPixels * 0.75f; val b = m.heightPixels * 0.25f
        gesture(Path().apply { moveTo(x, if (next) a else b); lineTo(x, if (next) b else a) }, 250)
    }

    fun doubleTapCenter() {
        val m = resources.displayMetrics
        val p = Path().apply { moveTo(m.widthPixels / 2f, m.heightPixels / 2f) }
        gesture(p, 40)
        android.os.Handler(mainLooper).postDelayed({ gesture(p, 40) }, 120)
    }
}
