package com.rudra.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Always-on listener. Say "Rudra ..." (or "Rudra", then the command). */
class RudraService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var sr: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private lateinit var pill: Pill
    private var awake = false
    private var alive = true

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rudra", "Rudra", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "rudra").setContentTitle("Rudra sun raha hai")
            .setContentText("\"Rudra\" bolkar command do").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        pill = Pill(this)
        tts = TextToSpeech(this) { tts.language = Locale("hi", "IN") }
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) {
                r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { process(it) }
                next(300)
            }
            override fun onError(e: Int) = next(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 700)
            override fun onPartialResults(p: Bundle?) {
                val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                if (awake || t.lowercase().contains("rudra") || t.contains("रुद्र")) pill.show(t)
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        listen()
    }

    private fun next(ms: Long) { if (alive) h.postDelayed({ listen() }, ms) }

    private fun listen() {
        if (!alive) return
        if (tts.isSpeaking) { next(600); return }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        runCatching { sr.startListening(i) }
    }

    private fun process(t: String) {
        val s = t.lowercase()
        val w = Regex("rudra|रुद्र|rudr").find(s)
        if (w != null) {
            val cmd = s.substring(w.range.last + 1).trim()
            if (cmd.isEmpty()) { awake = true; reply("Haan boliye") } else run(cmd)
        } else if (awake) { awake = false; run(s) }
    }

    private fun run(cmd: String) { awake = false; pill.show(cmd); Router.handle(this, cmd, ::reply) }

    private fun reply(t: String) { pill.show(t); tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "r") }

    override fun onDestroy() { alive = false; h.removeCallbacksAndMessages(null); sr.destroy(); tts.shutdown(); pill.destroy(); super.onDestroy() }
}
